# Notepadqq

Represents the entire application.

[TOC]

## nqq.commandLineArguments()

Returns the list of command line arguments passed to Notepadqq.

## nqq.version()

Returns the version of Notepadqq.

## nqq.windows()

Returns a list of [`Window`](Window) object, one for each open window.