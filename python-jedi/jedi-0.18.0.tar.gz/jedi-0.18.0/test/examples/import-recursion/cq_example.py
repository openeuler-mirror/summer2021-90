import cadquery_simple as cq

cq.
